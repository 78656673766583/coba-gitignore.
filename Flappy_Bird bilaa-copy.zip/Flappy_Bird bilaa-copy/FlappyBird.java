import greenfoot.*;
public class FlappyBird extends Actor
{
    private double a = 1;
    private int b = 200;
    private boolean haspressed = false;
    private boolean isalive = true;
    private boolean isacross = false;
    private boolean hasaddscore = false;
    public FlappyBird()
    {
       GreenfootImage image = getImage();
       image.scale(50,40);
    }
    public void act() 
    {
          if(spacePressed())
          {
              a=-2;
          }
          a+=0.1;
          b+=a;
          setLocation(getX(), (int)(b));
          if(isTouchPipe())
          {
             isalive = false;   
          }
          if(isTouchPipe())
          {
             isalive = false;   
          }
          if(!isalive)
          {
              getWorld().addObject(new GameOver(), 300, 200);
              getWorld().removeObject(this); 
          }
          if(!hasaddscore && isacross && isalive)
          {
                Greenfoot.playSound("score.mp3");
                Score.add(1);
          }
          hasaddscore = isacross;         
    }    
    public boolean spacePressed()
    {
       boolean pressed = false;
       if(Greenfoot.isKeyDown("Space"))
       {
           if(!haspressed)
           {
               Greenfoot.playSound("fly.mp3");
               pressed = true;
           }
           haspressed = true;
       }
       else
       {
           haspressed = false;
       }
       return pressed;
    }
    public boolean isTouchPipe()
    {
        isacross = false;
        for(Pipe pipe : getWorld().getObjects(Pipe.class))
        {
            if(Math.abs(pipe.getX() - getX()) < 69)
            {
            if(Math.abs(pipe.getY() + 30 - getY()) > 37)
            {
                Greenfoot.playSound("out.mp3");
                isalive = false;
            }
            isacross = true;
        } 
        }
        return !isalive;
    }
}
